package com.cg.lab3.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoArtifactApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoArtifactApplication.class, args);
		
	}

}
