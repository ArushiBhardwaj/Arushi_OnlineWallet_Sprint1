package com.cg.lab1.exercise4;

public class Employee {
	int employeeId;
	String employeeName;
	double salary;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String toString()
	{   System.out.println("Employee: [empId:  "+employeeId+", empName:  "+employeeName+", empSalary:  "+salary+"]");
//	    System.out.println(getSbuDetails());
		return "";
	}
	

}
