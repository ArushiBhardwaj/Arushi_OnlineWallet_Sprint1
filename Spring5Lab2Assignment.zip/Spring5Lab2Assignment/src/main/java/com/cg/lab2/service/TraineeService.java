package com.cg.lab2.service;

import java.util.List;

import com.cg.lab2.entity.Trainee;

public interface TraineeService {
	void addTrainee(Trainee trainee);
	List<Trainee> findAll();
	Trainee findById(int id);
	void deleteById(int id);
	Trainee update(Trainee trainee, int traineeId);
	
}
